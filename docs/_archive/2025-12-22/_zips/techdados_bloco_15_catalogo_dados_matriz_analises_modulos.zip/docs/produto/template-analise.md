# Template — Nova Análise (padrão TechDados)

## Nome da análise
- Identificador: TD-Axx
- Módulo/Submódulo:

## Pergunta que responde
- (descrição curta)

## Dados necessários
- Datasets:
- Chaves:
- Janela temporal:

## Métricas (referência)
- (link para docs/dados/dicionario-metricas.md)

## Filtros
- território:
- período:
- outros:

## Visualizações
- gráfico/tabela/mapa:
- cards:

## Export
- CSV? Parquet? PDF?
- RBAC necessário (`td:export`?)

## RBAC / Hierarquia de acesso
- perfis permitidos:
- restrições territoriais:
- observações LGPD:

## Validações
- checks de qualidade:
- limites:
