# Referências normativas (PDFs)

Este diretório contém documentos externos (PDFs) usados como referência normativa.

Regras:
- Não editar PDFs aqui.
- Preferir nomes de arquivo normalizados (sem espaços).
- Sempre criar/atualizar um `.md` em `docs/seguranca/` apontando para o PDF.
