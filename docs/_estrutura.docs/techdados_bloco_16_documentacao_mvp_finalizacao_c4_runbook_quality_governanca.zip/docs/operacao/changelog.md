# Changelog — TechDados

## 2025-12-17
- Blocos 01–16: fundação + wiring + RBAC + upstream + catálogo de dados + governança/documentação MVP
