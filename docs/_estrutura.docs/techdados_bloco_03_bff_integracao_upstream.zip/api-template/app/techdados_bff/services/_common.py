from __future__ import annotations

from typing import Any
from app.techdados_bff.infra.techdengue_api import TechdengueUpstream
